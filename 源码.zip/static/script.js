document.onkeydown = function (e) {
    if (e.key === "F12") {
        e.preventDefault();
    }
};

document.body.oncontextmenu = function (e) {
    e.preventDefault();
};
function toggleClass(selector, className) {
    var elements = document.querySelectorAll(selector);
    elements.forEach(function (element) {
        element.classList.toggle(className);
    });
}

function wx(imageURL) {
    toggleClass(".tc", "active");
    toggleClass(".tc-main", "active");

    var tcMainElement = document.querySelector(".tc-img");
    if (imageURL) {
        tcMainElement.src = imageURL;
    }
}
